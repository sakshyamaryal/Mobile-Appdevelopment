package com.example.quiz;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class QuizActivity extends AppCompatActivity {
    private List<QuestionModel> listQuestion;
    private TextView score, questionNum, newQuestion;
    private RadioGroup radioGroup;
    private RadioButton radioButton1,radioButton2,radioButton3,radioButton4;
    private Button next;
    private QuestionModel question;
    int counter;
    int allQuestions;
    int questionCount;

    boolean answer;
//    ColorStateList color;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);



        listQuestion = new ArrayList<>();
        extraQuestions(); // method name
        allQuestions = listQuestion.size();
        questionFormat(); //method name

        newQuestion = findViewById(R.id.textView2);
        score = findViewById(R.id.score);
//        score = findViewById(R.id.score);
        questionNum = findViewById(R.id.question);


        radioGroup=findViewById(R.id.rgroup);
        radioButton1 = findViewById(R.id.radioButton1);
        radioButton2 = findViewById(R.id.radioButton2);
        radioButton3 = findViewById(R.id.radioButton3);
        radioButton4 = findViewById(R.id.radioButton4);
        next = findViewById(R.id.button);


//        color = radioButton1.getTextColors();


        next.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                if (answer==false){
                    if (radioButton1.isChecked()||radioButton2.isChecked()||radioButton3.isChecked()||radioButton4.isChecked()){
                        answerCheck();
                    }
                    else {
                          showAlert("Select option");
                    }

                }
                else {
                       extraQuestions();
                }

            }

        });



    }
    private void showAlert(String warning) {
        AlertDialog dialog = new AlertDialog.Builder(QuizActivity.this)
                .setTitle("option")
                .setMessage(warning)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).create();
        dialog.show();
    }

    private void answerCheck() {
        answer = true;
        RadioButton select = findViewById(radioGroup.getCheckedRadioButtonId());
        int ans = radioGroup.indexOfChild(select) + 1; //selecting raadio button
        if (ans == question.getCorrect()){
              counter++;
              score.setText("Score"  +  counter);

        }
    }

    private void questionFormat() {

        if (questionCount < allQuestions){
            question = listQuestion.get(questionCount);     //currnet question
            newQuestion.setText(question.getQuestions());
            radioButton1.setText(question.getOpt1());
            radioButton2.setText(question.getOpt2());
            radioButton3.setText(question.getOpt3());
            radioButton4.setText(question.getOpt4());
            questionCount++;


            next.setText("Submit answers");
            questionNum.setText("Question " + questionCount);
            answer = false;
        }
        else {
            finish();
        }

        radioGroup.clearCheck();;
//        radioButton1.setTextColor(color);
//        radioButton2.setTextColor(color);
//        radioButton3.setTextColor(color);
//        radioButton4.setTextColor(color);
    }


    private void extraQuestions(){
        listQuestion.add(new QuestionModel("Which is higest mountain in the world" ,"mt everest","ketu","c","d",1));
        listQuestion.add(new QuestionModel("prime minster of nepal" ,"kp","serbadur","c","d",1));
        listQuestion.add(new QuestionModel("c is correct" ,"a","b","c","d",1));
        listQuestion.add(new QuestionModel("A is correct" ,"a","b","c","d",1));
        listQuestion.add(new QuestionModel("A is correct" ,"a","b","c","d",1));
        listQuestion.add(new QuestionModel("A is correct" ,"a","b","c","d",1));
        listQuestion.add(new QuestionModel("A is correct" ,"a","b","c","d",1));
    }
}